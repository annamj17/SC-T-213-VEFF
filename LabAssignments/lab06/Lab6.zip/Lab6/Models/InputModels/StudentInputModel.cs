using System.ComponentModel.DataAnnotations;

namespace Lab6.Models.InputModels
{
    public class StudentInputModel
    {
        public int Age { get; set; }
        public string Name { get; set; }
    }
}
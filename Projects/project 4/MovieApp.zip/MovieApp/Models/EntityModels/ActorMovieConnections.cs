namespace MovieApp.Models.EntityModels
{
    public class ActorMovieConnections
    {
        public int MovieId { get; set; }

        public int ActorId { get; set; }
    }
}
namespace MovieApp.Models.ViewModels
{

    public class ActorViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
    }
}